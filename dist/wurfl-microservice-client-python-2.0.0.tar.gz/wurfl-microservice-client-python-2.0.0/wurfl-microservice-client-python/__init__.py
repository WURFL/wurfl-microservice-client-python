from wmclient import WmClient, WmClientError, JsonDeviceOsVersion, JSONModelMktName
from model import JsonDeviceData, JsonInfoData, Request

__version__ = '2.0.0'
