HEADERS_CACHE_TYPE = "head-cache"
DEVICE_ID_CACHE_TYPE = "dId-cache"
